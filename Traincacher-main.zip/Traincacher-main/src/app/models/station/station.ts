export interface Station {
    id: string;
    locationX: string;
    locationY: string;
    name: string;
    standardname: string;
}