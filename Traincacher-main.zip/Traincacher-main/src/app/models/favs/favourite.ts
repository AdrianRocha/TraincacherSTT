export interface Favourite {
    id: string;
    from: string;
    to: string;
    url: string;
}