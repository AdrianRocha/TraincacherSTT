export interface VehicleInfo{
    id: string;
    name: string;
    number: string;
    shortname: string;
    type: string;
}