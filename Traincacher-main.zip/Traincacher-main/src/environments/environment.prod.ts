export const environment = {
  production: true,
  GOOGLE_MAPS_API_KEY: "AIzaSyAtbb8BpzhbD8N_8wMlyFhxsWBVnY9q_XU"
};
